<?php
// Site Configuration
define('SITE_NAME', 'BLVD Specialty Coffee');
define('SITE_TAGLINE', 'Coffee Co.');
define('SITE_DESCRIPTION', 'Pet-friendly specialty coffee cafe in Canning Vale with gluten-free, vegan, and vegetarian options. Shaded alfresco seating welcomes dogs.');
define('SITE_KEYWORDS', 'pet friendly cafe, dog friendly cafe, gluten free cafe, vegan cafe, vegetarian cafe, specialty coffee, Canning Vale, Perth, alfresco dining');

// Contact Information
define('CONTACT_ADDRESS', '96 Waratah Boulevard');
define('CONTACT_CITY', 'Canning Vale');
define('CONTACT_STATE', 'WA');
define('CONTACT_ZIP', '6155');
define('CONTACT_COUNTRY', 'Australia');
define('CONTACT_PHONE', '+61 401 201 536');
define('CONTACT_EMAIL', 'lankawebnets@gmail.com');

// Email Sender Configuration
define('EMAIL_FROM_NAME', 'BLVD Specialty Coffee');
define('EMAIL_FROM_ADDRESS', 'noreply@blvdsc.com.au');


// Department Emails
define('EMAIL_CATERING', 'lankawebnets@gmail.com');
define('EMAIL_EVENTS', 'lankawebnets@gmail.com');
define('EMAIL_CAREERS', 'lankawebnets@gmail.com');
define('EMAIL_MEDIA', 'lankawebnets@gmail.com');

// Social Media
define('SOCIAL_FACEBOOK', 'https://facebook.com/blvdcoffee');
define('SOCIAL_INSTAGRAM', 'https://instagram.com/blvdcoffee');
define('SOCIAL_TWITTER', 'https://twitter.com/blvdcoffee');

// Opening Hours
$opening_hours = [
    'weekday' => 'Monday - Friday: 7:00 AM - 1:30 PM',
    'weekend' => 'Saturday - Sunday: 8:00 AM - 1:30 PM',
];

// Base URL (automatically detects correct path for any domain)
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];

// Automatically detect base path
$script_name = dirname($_SERVER['SCRIPT_NAME']);
$base_path = ($script_name === '/' || $script_name === '\\') ? '' : $script_name;

define('BASE_URL', $protocol . '://' . $host . $base_path);

// Helper function to get current page
function get_current_page() {
    $page = basename($_SERVER['PHP_SELF'], '.php');
    return $page === 'index' ? 'home' : $page;
}

// Helper function to check if page is active
function is_active($page_name) {
    $current = get_current_page();
    if ($page_name === 'home' && $current === 'home') return true;
    if ($page_name === $current) return true;
    return false;
}
?>
